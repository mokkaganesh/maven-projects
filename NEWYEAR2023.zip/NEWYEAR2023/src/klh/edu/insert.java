package klh.edu;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/insert")
public class insert extends HttpServlet {
private static final long serialVersionUID = 1L;
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String me=request.getParameter("ny");
		try{
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db2023",
							 "root","sairam");
			Statement stmt = con.createStatement();
		   	String sql="insert into ny(wish)values('"+me+"')";
   			int r=stmt.executeUpdate(sql);
					if(r>0)
					System.out.println("inserted sucessfully");	
				}catch(Exception e){System.out.println(e);}
				
				
			}

		
		
	}


