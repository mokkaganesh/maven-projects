# Virtual-Classroom
Teaching tool to assist each and every student to learn in an interactive manner in today’s situation of a pandemic
